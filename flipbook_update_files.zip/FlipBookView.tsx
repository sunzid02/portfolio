import { useEffect, useMemo, useState } from "react";

type Props = {
  id?: string;
  title?: string;
  pages: React.ReactNode[];
  initialIndex?: number;
};

export default function FlipBookView({
  id = "flipbook",
  title,
  pages,
  initialIndex = 0,
}: Props) {
  const total = pages.length;
  const safeInitial = Math.min(Math.max(initialIndex, 0), Math.max(total - 1, 0));

  const [index, setIndex] = useState<number>(safeInitial);
  const [dir, setDir] = useState<"next" | "prev">("next");

  const canPrev = index > 0;
  const canNext = index < total - 1;

  const labels = useMemo(() => {
    const region = title ? `${title} flipbook` : "Flipbook";
    const page = `Page ${index + 1} of ${Math.max(total, 1)}`;
    return { region, page };
  }, [title, index, total]);

  const goPrev = () => {
    if (!canPrev) return;
    setDir("prev");
    setIndex((v) => v - 1);
  };

  const goNext = () => {
    if (!canNext) return;
    setDir("next");
    setIndex((v) => v + 1);
  };

  const goTo = (i: number) => {
    if (i < 0 || i > total - 1) return;
    setDir(i > index ? "next" : "prev");
    setIndex(i);
  };

  // Keyboard support: arrows, home/end
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") goPrev();
      if (e.key === "ArrowRight") goNext();
      if (e.key === "Home") goTo(0);
      if (e.key === "End") goTo(total - 1);
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, total]);

  // Simple swipe support (pointer)
  useEffect(() => {
    const el = document.getElementById(id);
    if (!el) return;

    let startX = 0;
    let active = false;

    const onDown = (e: PointerEvent) => {
      active = true;
      startX = e.clientX;
    };

    const onUp = (e: PointerEvent) => {
      if (!active) return;
      active = false;

      const dx = e.clientX - startX;
      if (Math.abs(dx) < 40) return;

      if (dx > 0) goPrev();
      else goNext();
    };

    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointerup", onUp);

    return () => {
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointerup", onUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, index, total]);

  if (!total) return null;

  return (
    <div className="flipbook-wrap" aria-label={labels.region}>
      <div className="flipbook-head">
        <div className="flipbook-left">
          {title ? <h3 className="flipbook-title">{title}</h3> : null}
          <span className="flipbook-count" aria-label={labels.page}>
            {index + 1}/{total}
          </span>
        </div>

        <div className="flipbook-controls">
          <button
            className="flipbook-btn"
            type="button"
            onClick={goPrev}
            disabled={!canPrev}
            aria-label="Previous page"
            title="Previous"
          >
            ←
          </button>

          <button
            className="flipbook-btn"
            type="button"
            onClick={goNext}
            disabled={!canNext}
            aria-label="Next page"
            title="Next"
          >
            →
          </button>
        </div>
      </div>

      <div
        id={id}
        className="flipbook-stage"
        role="group"
        aria-label={labels.page}
        tabIndex={0}
      >
        <div className={`flipbook-page flipbook-${dir}`} key={`${id}-${index}`}>
          <div className="flipbook-page-inner">{pages[index]}</div>
        </div>
      </div>

      <div className="flipbook-dots" aria-label="Page navigation">
        {pages.map((_, i) => (
          <button
            key={`${id}-dot-${i}`}
            type="button"
            className={`flipbook-dot ${i === index ? "is-active" : ""}`}
            onClick={() => goTo(i)}
            aria-label={`Go to page ${i + 1}`}
            title={`Page ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
